import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { randomUUID } from 'crypto';
import { handleAIChatRequest } from './server/aiService.js';
import {
  handlePosCheckout,
  handleOrderCancellation,
  handleCustomerRefund,
  handleExpenseCreation,
  handleSalaryDisbursement,
  handlePayrollProcess,
  handleAttendanceClockIn,
  handleAttendanceClockOut,
  handleAttendanceManual,
  handlePurchaseRegistration,
  handleBankTransaction,
  handleInventoryAdjustment,
  handleApplyStockCount,
  handleStockUpdate,
  handleKitchenStatusUpdate,
  handleDeliveryStatusUpdate,
  handleDeliveryAssignDriver,
  handleOrderUpdate,
  handleCreateAccount,
  handleUpdateAccount,
  handleCreateJournalEntry,
  handleCreateRevenue,
  handleCreateReceivable,
  handleRecordARPayment,
  handleCreatePayable,
  handleRecordAPPayment,
  handleOpenCashRegister,
  handleCloseCashRegister,
  handleCreateBankAccount,
  handleCreateTax,
  handleUpdateTax,
  handleReceiveGoods,
  handleRecordSupplierPayment,
  handleKitchenTicketUpdate,
  handleKitchenStationStatusUpdate,
  handleWalletRecharge,
  handleWalletDeduct,
  handleWalletRefund,
  handleGetFinancialSummary,
  handleCreateInventoryItem,
  handleUpdateInventoryItem,
  handleDeleteInventoryItem,
  handleBranchTransferApproval, handleBranchTransferCreate, handleBranchTransferRejection, handleProductOptionCreate, handleProductOptionUpdate, handleProductOptionDelete,
  handleCreatePurchaseOrder,
  handleUpdatePurchaseOrder,
  handleApprovePurchaseOrder,
  handleCreateDeliveryOrder,
  handleDeliveryTracking,
  handleLogKitchenWaste,
  handleDeliveryRating,
  handleCreateDeliveryNotification,
  handleLogActivity,
  handleRegisterDevice,
  handleMarkNotificationRead,
  handleAIExecuteAction,
  handleCustomerPointsAdd,
  handleCustomerPointsRedeem,
  handleCreateReward,
  handleUpdateReward,
  handleDeleteReward,
  handleCreateCoupon,
  handleUpdateCoupon,
  handleDeleteCoupon,
  handleAdminCreateUser,
  handleAdminUpdateUser,
  handleInitialSetup,
  handleGetBranchSettings,
  handleUpdateBranchSettings,
  handleCreateRecipe,
  handleUpdateRecipe,
  handleDeleteRecipe,
  handleCreateIngredient,
  handleUpdateIngredient,
  handleDeleteIngredient,
  handleDiagnosticsPing,
  handleGetAccountingPeriods,
  handleSaveAccountingPeriod,
  handleUpdateAccountingPeriodStatus,
  handleCreatePurchaseReturn,
  handleGetPurchaseReturns,
  handleCreateStockCount,
  handleGetReservations,
  handleCreateReservation,
  handleUpdateReservationStatus,
  handleGetAuditLogs
} from './server/trustedFinancialBackend.js';

dotenv.config();

export const app = express();
// Render/Cloud Run sit behind a trusted reverse proxy; use the proxy-aware client IP for rate limiting.
app.set('trust proxy', 1);
// Port resolution: adopt platform-provided PORT (e.g. Cloud Run 8080 or Render), with fallback to 3000
const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;

// P3-01: Production Security Headers & Strict CORS Allowlist Middleware
export function isOriginAllowed(origin?: string): boolean {
  if (!origin) return true; // Same-origin or non-browser / server-to-server requests
  try {
    const parsed = new URL(origin);
    const host = parsed.hostname.toLowerCase();
    const isProd = String(process.env.NODE_ENV || '').toLowerCase() === 'production';

    // Allow local development only in non-production environments
    if (!isProd && (host === 'localhost' || host === '127.0.0.1' || host === '0.0.0.0')) {
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    }

    // All non-local origins MUST use HTTPS
    if (parsed.protocol !== 'https:') {
      return false;
    }

    // Strict match for the production Vercel frontend
    if (parsed.origin === 'https://baba-sultan-restaurant.vercel.app') {
      return true;
    }

    // Allow project-specific Firebase Hosting domains only (never wildcard *.web.app or *.firebaseapp.com)
    const firebaseProjectId = String(
      process.env.FIREBASE_PROJECT_ID || process.env.VITE_FIREBASE_PROJECT_ID || 'babasultan-restaurant'
    ).trim().toLowerCase();
    if (
      firebaseProjectId &&
      (
        host === `${firebaseProjectId}.web.app` ||
        host === `${firebaseProjectId}.firebaseapp.com` ||
        (host.startsWith(`${firebaseProjectId}--`) && (host.endsWith('.web.app') || host.endsWith('.firebaseapp.com')))
      )
    ) {
      return true;
    }

    // Allow AI Studio preview and service-specific Cloud Run preview URLs
    if (
      host === 'ai.studio' ||
      host.endsWith('.ai.studio') ||
      host === 'aistudio.google.com' ||
      host.endsWith('.run.app') ||
      host.endsWith('.google.com') ||
      host.endsWith('.googleusercontent.com') ||
      /^babasultan-api-[a-z0-9-]+(\.[a-z0-9-]+)?\.run\.app$/i.test(host) ||
      /^ais-(dev|pre)-[a-z0-9-]+(\.[a-z0-9-]+)?\.run\.app$/i.test(host)
    ) {
      return true;
    }

    // Allow explicitly configured application domains via environment variables
    const envOrigins = [
      process.env.FRONTEND_URL,
      process.env.APP_URL,
      process.env.VITE_APP_URL,
      process.env.ALLOWED_ORIGINS
    ].filter(Boolean) as string[];

    for (const envOrigin of envOrigins) {
      for (const single of envOrigin.split(',')) {
        const trimmed = single.trim();
        if (!trimmed || trimmed === '*') continue;
        try {
          if (new URL(trimmed).origin === parsed.origin) return true;
        } catch {
          if (trimmed === origin) return true;
        }
      }
    }
    return false;
  } catch {
    return false;
  }
}

app.use((req, res, next) => {
  const incomingReqId = req.headers['x-request-id'] || req.headers['x-correlation-id'];
  const requestId = (Array.isArray(incomingReqId) ? incomingReqId[0] : incomingReqId || '').trim() || randomUUID();
  (req as any).requestId = requestId;
  (req as any).correlationId = requestId;
  res.setHeader('X-Request-Id', requestId);
  res.setHeader('X-Correlation-Id', requestId);

  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  const allowedFrameAncestors = [
    "'self'",
    'https://ai.studio',
    'https://aistudio.google.com',
    'https://*.google.com',
    'https://*.googleusercontent.com',
    'https://*.run.app',
    'https://*.firebaseapp.com',
    'https://*.web.app',
    'https://*.render.com'
  ];
  if (process.env.FRONTEND_URL) {
    try {
      const parsed = new URL(process.env.FRONTEND_URL);
      if (!allowedFrameAncestors.includes(parsed.origin)) {
        allowedFrameAncestors.push(parsed.origin);
      }
    } catch {}
  }
  res.setHeader('Content-Security-Policy', `frame-ancestors ${allowedFrameAncestors.join(' ')}`);

  if (String(process.env.NODE_ENV || '').toLowerCase() === 'production') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }

  const origin = req.headers.origin;
  const allowed = isOriginAllowed(origin);

  if (origin && allowed) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, Idempotency-Key, X-Idempotency-Key, X-Request-Id, X-Correlation-Id, X-Requested-With');
    res.setHeader('Access-Control-Expose-Headers', 'X-Request-Id, X-Correlation-Id, X-Idempotent-Replay, Retry-After');
    res.setHeader('Access-Control-Max-Age', '86400');
    res.setHeader('Vary', 'Origin');
  }

  if (req.method === 'OPTIONS') {
    if (origin && !allowed) {
      return res.status(403).json({ error: 'CORS policy violation: Origin not allowed.', requestId });
    }
    return res.sendStatus(204);
  }
  next();
});

app.use(express.json({ limit: '1mb' }));

// Lightweight in-process rate limiting with bounded memory management.
// Deployments with multiple instances should additionally enforce limits at the edge/load-balancer layer.
export const RATE_LIMIT_MAX_ENTRIES = 5000;
export const rateState = new Map<string, { count: number; resetAt: number }>();

export function cleanupRateState(now: number = Date.now()): void {
  // 1. Evict expired entries
  for (const [k, v] of rateState.entries()) {
    if (v.resetAt <= now) {
      rateState.delete(k);
    }
  }
  // 2. Bound maximum size if still above limit by deleting oldest entries
  if (rateState.size >= RATE_LIMIT_MAX_ENTRIES) {
    const overflow = rateState.size - RATE_LIMIT_MAX_ENTRIES + 1;
    let evicted = 0;
    for (const k of rateState.keys()) {
      rateState.delete(k);
      evicted++;
      if (evicted >= overflow) break;
    }
  }
}

app.use('/api', (req, res, next) => {
  if (process.env.VITEST === 'true' || process.env.NODE_ENV === 'test') return next();
  const now = Date.now();
  const key = `${req.ip}:${req.path.startsWith('/ai') ? 'ai' : req.method}`;
  const windowMs = 60_000;
  const max = req.path.startsWith('/ai') ? 30 : 120;

  // Opportunistic bounded cleanup when table is getting large or every ~100 requests
  if (rateState.size >= RATE_LIMIT_MAX_ENTRIES || Math.random() < 0.01) {
    cleanupRateState(now);
  }

  const current = rateState.get(key);
  if (!current || current.resetAt <= now) {
    if (!current && rateState.size >= RATE_LIMIT_MAX_ENTRIES) {
      cleanupRateState(now);
    }
    rateState.set(key, { count: 1, resetAt: now + windowMs });
    return next();
  }
  current.count += 1;
  if (current.count > max) {
    res.setHeader('Retry-After', Math.ceil((current.resetAt - now) / 1000));
    return res.status(429).json({ error: 'Too many requests. Please retry later.' });
  }
  return next();
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: Math.floor(process.uptime()),
    requestId: (req as any).requestId
  });
});

// P0 Trusted Financial & Operational Endpoints (Firebase Admin SDK Server Execution)
app.post('/api/pos/complete', handlePosCheckout);
app.post('/api/pos/checkout', handlePosCheckout);
app.post('/api/orders/:orderId/cancel', handleOrderCancellation);
app.post('/api/orders/:orderId/refund', handleCustomerRefund);
app.post('/api/pos/refund', handleCustomerRefund);
app.post('/api/pos/orders/:orderId/refund', handleCustomerRefund);
app.post('/api/expenses', handleExpenseCreation);
app.post('/api/salaries', handleSalaryDisbursement);
app.post('/api/payroll/process', handlePayrollProcess);
app.post('/api/hrm/attendance/clock-in', handleAttendanceClockIn);
app.post('/api/hrm/attendance/:id/clock-out', handleAttendanceClockOut);
app.post('/api/hrm/attendance/manual', handleAttendanceManual);
app.post('/api/purchases', handlePurchaseRegistration);
app.post('/api/bank-transactions', handleBankTransaction);
app.post('/api/bank-transaction', handleBankTransaction);
app.post('/api/accounting/bank-transactions', handleBankTransaction);
app.post('/api/accounting/bank-transaction', handleBankTransaction);
app.post('/api/inventory/adjust', handleInventoryAdjustment);
app.post('/api/inventory/stock-count/apply', handleApplyStockCount);
app.post('/api/inventory/stock', handleStockUpdate);
app.post('/api/kitchen/:ticketId/status', handleKitchenStatusUpdate);
app.post('/api/kitchen/:ticketId/update', handleKitchenTicketUpdate);
app.post('/api/kitchen/stations/:stationId/status', handleKitchenStationStatusUpdate);
app.post('/api/deliveries/:deliveryId/status', handleDeliveryStatusUpdate);
app.post('/api/deliveries/:deliveryId/assign', handleDeliveryAssignDriver);
app.post('/api/deliveries/notifications', handleCreateDeliveryNotification);
app.post('/api/orders/:orderId/update', handleOrderUpdate);
app.post('/api/branch-transfers', handleBranchTransferCreate);
app.post('/api/branch-transfers/:transferId/approve', handleBranchTransferApproval);
app.post('/api/branch-transfers/:transferId/reject', handleBranchTransferRejection);
app.post('/api/product-options', handleProductOptionCreate);
app.post('/api/product-options/:id', handleProductOptionUpdate);
app.delete('/api/product-options/:id', handleProductOptionDelete);

// Accounting & Purchasing API Routes
app.post('/api/accounting/accounts', handleCreateAccount);
app.post('/api/accounting/accounts/:id', handleUpdateAccount);
app.post('/api/accounting/journal-entries', handleCreateJournalEntry);
app.post('/api/accounting/revenues', handleCreateRevenue);
app.post('/api/accounting/receivables', handleCreateReceivable);
app.post('/api/accounting/receivables/:id/payment', handleRecordARPayment);
app.post('/api/accounting/payables', handleCreatePayable);
app.post('/api/accounting/payables/:id/payment', handleRecordAPPayment);
app.post('/api/accounting/cash-registers/open', handleOpenCashRegister);
app.post('/api/accounting/cash-registers/close', handleCloseCashRegister);
app.post('/api/accounting/bank-accounts', handleCreateBankAccount);
app.post('/api/accounting/taxes', handleCreateTax);
app.post('/api/accounting/taxes/:id', handleUpdateTax);
app.get('/api/accounting/periods', handleGetAccountingPeriods);
app.post('/api/accounting/periods', handleSaveAccountingPeriod);
app.post('/api/accounting/periods/:id/status', handleUpdateAccountingPeriodStatus);
app.post('/api/purchases/receive', handleReceiveGoods);
app.post('/api/purchases/supplier-payment', handleRecordSupplierPayment);
app.get('/api/purchases/returns', handleGetPurchaseReturns);
app.post('/api/purchases/returns', handleCreatePurchaseReturn);
app.post('/api/purchases/orders', handleCreatePurchaseOrder);
app.post('/api/purchases/orders/:id/update', handleUpdatePurchaseOrder);
app.post('/api/purchases/orders/:id/approve', handleApprovePurchaseOrder);
app.post('/api/inventory/stock-count', handleCreateStockCount);
app.get('/api/reservations', handleGetReservations);
app.post('/api/reservations', handleCreateReservation);
app.post('/api/reservations/:id/status', handleUpdateReservationStatus);
app.get('/api/audit/logs', handleGetAuditLogs);
app.post('/api/inventory/items', handleCreateInventoryItem);
app.post('/api/inventory/items/:id/update', handleUpdateInventoryItem);
app.post('/api/inventory/items/:id/delete', handleDeleteInventoryItem);
app.delete('/api/inventory/items/:id', handleDeleteInventoryItem);
app.post('/api/recipes', handleCreateRecipe);
app.post('/api/recipes/:id/update', handleUpdateRecipe);
app.put('/api/recipes/:id', handleUpdateRecipe);
app.patch('/api/recipes/:id', handleUpdateRecipe);
app.delete('/api/recipes/:id', handleDeleteRecipe);
app.post('/api/recipes/ingredients', handleCreateIngredient);
app.post('/api/recipes/ingredients/:id/update', handleUpdateIngredient);
app.put('/api/recipes/ingredients/:id', handleUpdateIngredient);
app.patch('/api/recipes/ingredients/:id', handleUpdateIngredient);
app.delete('/api/recipes/ingredients/:id', handleDeleteIngredient);
app.post('/api/diagnostics/ping', handleDiagnosticsPing);
app.post('/api/system/diagnostics/ping', handleDiagnosticsPing);
app.post('/api/deliveries', handleCreateDeliveryOrder);
app.post('/api/deliveries/:deliveryId/tracking', handleDeliveryTracking);
app.post('/api/deliveries/:deliveryId/rating', handleDeliveryRating);
app.post('/api/kitchen/waste', handleLogKitchenWaste);
app.post('/api/audit/activity', handleLogActivity);

// Notification API Routes
app.post('/api/notifications/register-device', handleRegisterDevice);
app.post('/api/notifications/:id/read', handleMarkNotificationRead);

// CRM Wallet & Loyalty API Routes
app.post('/api/crm/wallet/recharge', handleWalletRecharge);
app.post('/api/crm/wallet/deduct', handleWalletDeduct);
app.post('/api/crm/wallet/refund', handleWalletRefund);
app.post('/api/wallet/recharge', handleWalletRecharge);
app.post('/api/wallet/deduct', handleWalletDeduct);
app.post('/api/wallet/refund', handleWalletRefund);
app.post('/api/crm/points/add', handleCustomerPointsAdd);
app.post('/api/crm/points/redeem', handleCustomerPointsRedeem);
app.post('/api/points/add', handleCustomerPointsAdd);
app.post('/api/points/redeem', handleCustomerPointsRedeem);
app.post('/api/crm/rewards', handleCreateReward);
app.post('/api/crm/rewards/:id/update', handleUpdateReward);
app.patch('/api/crm/rewards/:id', handleUpdateReward);
app.put('/api/crm/rewards/:id', handleUpdateReward);
app.delete('/api/crm/rewards/:id', handleDeleteReward);
app.post('/api/crm/coupons', handleCreateCoupon);
app.post('/api/crm/coupons/:id/update', handleUpdateCoupon);
app.patch('/api/crm/coupons/:id', handleUpdateCoupon);
app.put('/api/crm/coupons/:id', handleUpdateCoupon);
app.delete('/api/crm/coupons/:id', handleDeleteCoupon);

// User Management API Routes
app.post('/api/users/admin-create', handleAdminCreateUser);
app.post('/api/users/admin-update', handleAdminUpdateUser);
app.post('/api/setup/initial', handleInitialSetup);
app.get('/api/settings/branch', handleGetBranchSettings);
app.put('/api/settings/branch', handleUpdateBranchSettings);

// Financial Summary Route
app.get('/api/financial-summary', handleGetFinancialSummary);

// AI Assistant Endpoint using Gemini API
app.post('/api/ai-chat', handleAIChatRequest);
app.post('/api/ai/execute-action', handleAIExecuteAction);

// API 404 boundary: never let an unknown /api route fall through to the SPA
// catch-all. Unknown API paths must return a machine-readable 404 instead of
// index.html (which can otherwise mask routing/configuration errors).
app.all('/api', (_req, res) => {
  return res.status(404).json({ error: 'API endpoint not found.' });
});
app.all('/api/*', (_req, res) => {
  return res.status(404).json({ error: 'API endpoint not found.' });
});

// Central error boundary: never leak stack traces or internal implementation details to clients.
app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const status = Number(err?.statusCode || err?.status || 500);
  const safeStatus = status >= 400 && status < 600 ? status : 500;
  const requestId = (req as any).requestId;
  console.error('Unhandled API error', {
    requestId,
    method: req.method,
    path: req.path,
    status: safeStatus,
    message: err?.message || String(err)
  });
  if (res.headersSent) return;
  return res.status(safeStatus).json({
    error: safeStatus >= 500 ? 'Internal server error.' : (err?.message || 'Request failed.'),
    requestId
  });
});

// Vite Development or Production Server Static Middleware
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    // Block direct public access to backend bundle artifacts and sourcemaps
    app.use((req, res, next) => {
      const p = req.path.toLowerCase();
      if (p === '/server.cjs' || p === '/server.cjs.map' || p.endsWith('.map') || p.startsWith('/server.')) {
        return res.status(404).json({ error: 'Not found' });
      }
      next();
    });
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Restaurant ERP & AI Business Assistant server running on port ${PORT}`);
  });

  const gracefulShutdown = (signal: string) => {
    console.log(`[Server] Received ${signal}. Draining in-flight requests for graceful shutdown...`);
    const forceTimer = setTimeout(() => {
      console.error('[Server] Forced shutdown after drain timeout.');
      process.exit(1);
    }, 10_000);
    forceTimer.unref();

    server.close((err) => {
      clearTimeout(forceTimer);
      if (err) {
        console.error('[Server] Error during HTTP server close:', err);
        process.exit(1);
      }
      console.log('[Server] Graceful shutdown complete.');
      process.exit(0);
    });
  };

  process.once('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.once('SIGINT', () => gracefulShutdown('SIGINT'));
}

if (!process.env.VERCEL && !process.env.VITEST && process.env.NODE_ENV !== 'test') {
  startServer();
}
