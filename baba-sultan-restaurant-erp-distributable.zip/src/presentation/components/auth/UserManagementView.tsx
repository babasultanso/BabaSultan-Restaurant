import { translateRawUi } from '../../../i18n/rawUi';
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db, COLLECTIONS, getAuthToken, getApiUrl } from '../../../lib/firebase';
import { USER_ROLES, UserRole } from '../../../constants';
import { UserRecord, ActivityLog, Branch } from '../../../types';
import { Users, UserPlus, Shield, Search, Filter, Mail, KeyRound, RefreshCw, CheckCircle2, AlertTriangle, UserCheck, Clock, Edit2 } from 'lucide-react';

export const UserManagementView: React.FC = () => {
  const { user: currentUser, userRecord, role: currentRole, t, sendPasswordReset } = useAuth();
  const normalizedRole = String(currentRole || '').toLowerCase();
  const isOwnerUser = normalizedRole === 'owner';
  const isHqUser = isOwnerUser || (normalizedRole === 'admin' && (userRecord?.isHQ === true || userRecord?.branchId === 'all'));
  const currentBranchId = String(userRecord?.branchId || userRecord?.branch || '').trim();
  const assignableRoles: UserRole[] = isOwnerUser
    ? ['Owner', 'Admin', 'Manager', 'Accountant', 'Cashier', 'Kitchen', 'Waiter', 'Delivery Driver']
    : isHqUser
      ? ['Manager', 'Accountant', 'Cashier', 'Kitchen', 'Waiter', 'Delivery Driver']
      : ['Manager', 'Accountant', 'Cashier', 'Kitchen', 'Waiter', 'Delivery Driver'];

  const [users, setUsers] = useState<UserRecord[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [activeTab, setActiveTab] = useState<'users' | 'activity'>('users');

  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // New User Modal State
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('Manager');
  const [newBranch, setNewBranch] = useState('');
  const [creatingUser, setCreatingUser] = useState(false);

  // Edit User Modal State
  const [selectedUser, setSelectedUser] = useState<UserRecord | null>(null);
  const [editRole, setEditRole] = useState<UserRole>('Manager');
  const [editStatus, setEditStatus] = useState<'active' | 'suspended' | 'pending'>('active');
  const [updatingUser, setUpdatingUser] = useState(false);

  const [toastMsg, setToastMsg] = useState<string | null>(null);

  useEffect(() => {
    try {
      const usersQuery = currentBranchId && !isHqUser
        ? query(collection(db, COLLECTIONS.USERS), where('branchId', '==', currentBranchId))
        : collection(db, COLLECTIONS.USERS);
      const logsQuery = currentBranchId && !isHqUser
        ? query(collection(db, COLLECTIONS.ACTIVITY_LOGS), where('branchId', '==', currentBranchId))
        : collection(db, COLLECTIONS.ACTIVITY_LOGS);

      const unsubUsers = onSnapshot(usersQuery, (snapshot) => {
        const list = snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserRecord));
        setUsers(list);
      }, (err) => console.warn('Users listener error:', err));

      const unsubBranches = onSnapshot(collection(db, COLLECTIONS.BRANCHES), (snapshot) => {
        const list = snapshot.docs
          .map(d => ({ id: d.id, ...d.data() } as Branch))
          .filter((b) => isHqUser || b.id === currentBranchId)
          .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
        setBranches(list);
        setNewBranch((current) => current || list[0]?.id || '');
      }, (err) => console.warn('Branches listener error:', err));

      const unsubLogs = onSnapshot(logsQuery, (snapshot) => {
        const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ActivityLog));
        list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        setActivityLogs(list);
      }, (err) => console.warn('Activity logs listener error:', err));

      return () => { unsubUsers(); unsubBranches(); unsubLogs(); };
    } catch (e) {
      console.warn('UserManagement listeners error:', e);
    }
  }, [currentBranchId, isHqUser]);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newEmail) return;
    setCreatingUser(true);
    try {
      const token = await getAuthToken();
      const res = await fetch(getApiUrl('/api/users/admin-create'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          displayName: newName.trim(),
          email: newEmail.trim(),
          role: newRole,
          branch: newBranch,
          branchId: newBranch
        })
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Failed to create user: HTTP ${res.status}`);
      }

      setShowAddUserModal(false);
      setNewName('');
      setNewEmail('');
      try {
        await sendPasswordReset(newEmail.trim());
        setToastMsg(t.userManagement.userCreated);
      } catch (resetErr: any) {
        setToastMsg(`${t.userManagement.userCreated}. ${translateRawUi('Password reset email could not be sent; trigger it from the user row.')}`);
        console.warn('Post-provision password reset warning:', resetErr);
      }
      setTimeout(() => setToastMsg(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Failed to create user');
    } finally {
      setCreatingUser(false);
    }
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || selectedUser.uid === currentUser?.uid) return;
    setUpdatingUser(true);
    try {
      const token = await getAuthToken();
      const idempotencyKey = `admin-user-update-${selectedUser.uid}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const res = await fetch(getApiUrl('/api/users/admin-update'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Idempotency-Key': idempotencyKey,
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          uid: selectedUser.uid,
          role: editRole,
          status: editStatus,
          idempotencyKey
        })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `Failed to update user: HTTP ${res.status}`);
      setSelectedUser(null);
      setToastMsg(t.userManagement.userUpdated);
      setTimeout(() => setToastMsg(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Failed to update user');
    } finally {
      setUpdatingUser(false);
    }
  };

  const handleTriggerReset = async (userEmail: string) => {
    try {
      await sendPasswordReset(userEmail);
      setToastMsg(t.userManagement.resetEmailTriggered);
      setTimeout(() => setToastMsg(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Failed to trigger reset email');
    }
  };

  const filteredUsers = users.filter(u => {
    const nameStr = (u.displayName || '').toLowerCase();
    const emailStr = (u.email || '').toLowerCase();
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch = nameStr.includes(q) || emailStr.includes(q);
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    const matchesStatus = statusFilter === 'all' || u.status === statusFilter;
    return matchesSearch && matchesRole && matchesStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-6 right-6 z-50 bg-emerald-500 text-slate-950 font-bold px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 text-xs animate-bounce">
          <CheckCircle2 className="w-4 h-4" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-400" />
            <span>{t.userManagement.title}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">{t.userManagement.subtitle}</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddUserModal(true)}
            disabled={!isOwnerUser && !isHqUser}
            className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs transition flex items-center gap-2 shadow-lg shadow-emerald-950/40 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>{t.userManagement.addUser}</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'users'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>System Users ({users.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('activity')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            activeTab === 'activity'
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Audit Logs ({activityLogs.length})</span>
        </button>
      </div>

      {activeTab === 'users' ? (
        <div className="space-y-4">
          
          {/* Controls Bar */}
          <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="relative w-full md:w-72">
              <Search className="w-4 h-4 text-slate-500 absolute start-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.userManagement.searchUsers}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl ps-9 pe-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500/50"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              <Filter className="w-4 h-4 text-slate-500" />
              
              {/* Role Filter */}
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none"
              >
                <option value="all">{t.legacyUi.allRoles}</option>
                {assignableRoles.map(r => (
                  <option key={r} value={r}>{t.roles[r as keyof typeof t.roles] || r}</option>
                ))}
              </select>

              {/* Status Filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none"
              >
                <option value="all">{t.legacyUi.allStatuses}</option>
                <option value="active">{translateRawUi('Active')}</option>
                <option value="suspended">{translateRawUi('Suspended')}</option>
                <option value="pending">{t.legacyUi.pendingLabel}</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-start text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-4">{t.userManagement.userName}</th>
                    <th className="p-4">{t.userManagement.assignedRole}</th>
                    <th className="p-4">{t.userManagement.branchOffice}</th>
                    <th className="p-4">{t.userManagement.accountStatus}</th>
                    <th className="p-4">{t.userManagement.lastLogin}</th>
                    <th className="p-4 text-end">{t.userManagement.actions}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-500">
                        {translateRawUi('No user accounts match the current filter.')}
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((u) => (
                      <tr key={u.uid} className="hover:bg-slate-800/30 transition">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-white text-xs">
                              {u.displayName ? u.displayName.charAt(0).toUpperCase() : 'U'}
                            </div>
                            <div>
                              <p className="font-bold text-white">{u.displayName}</p>
                              <p className="text-[11px] text-slate-400">{u.email}</p>
                            </div>
                          </div>
                        </td>

                        <td className="p-4">
                          <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-lg font-semibold text-[11px]">
                            {t.roles[u.role as keyof typeof t.roles] || u.role}
                          </span>
                        </td>

                        <td className="p-4 text-slate-300 font-medium">
                          {u.branch || '—'}
                        </td>

                        <td className="p-4">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            u.status === 'active'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : u.status === 'suspended'
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          }`}>
                            {u.status || 'active'}
                          </span>
                        </td>

                        <td className="p-4 text-[11px] text-slate-400">
                          {u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleDateString() : 'Never'}
                        </td>

                        <td className="p-4 text-end space-x-2 rtl:space-x-reverse">
                          <button
                            onClick={() => {
                              setSelectedUser(u);
                              setEditRole(u.role);
                              setEditStatus(u.status || 'active');
                            }}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[11px] font-semibold transition inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>{t.legacyUi.editLabel}</span>
                          </button>

                          <button
                            onClick={() => handleTriggerReset(u.email)}
                            className="px-2.5 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg text-[11px] font-semibold transition inline-flex items-center gap-1 cursor-pointer"
                          >
                            <KeyRound className="w-3 h-3" />
                            <span>{translateRawUi('Reset Pass')}</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* Activity Logs View */
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <span>{t.activityLogs.title}</span>
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-800">
                <tr>
                  <th className="p-3">{t.activityLogs.timestamp}</th>
                  <th className="p-3">{t.activityLogs.user}</th>
                  <th className="p-3">{t.activityLogs.role}</th>
                  <th className="p-3">{t.activityLogs.action}</th>
                  <th className="p-3">{t.activityLogs.details}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {activityLogs.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-6 text-center text-slate-500">
                      {t.activityLogs.noLogs}
                    </td>
                  </tr>
                ) : (
                  activityLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/30">
                      <td className="p-3 text-[11px] text-slate-400 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="p-3 font-semibold text-white">
                        {log.userName || log.userEmail}
                      </td>
                      <td className="p-3">
                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                          {log.userRole}
                        </span>
                      </td>
                      <td className="p-3 font-bold text-amber-400 uppercase text-[10px]">
                        {log.action}
                      </td>
                      <td className="p-3 text-slate-300">
                        {log.details}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-emerald-400" />
                <span>{t.userManagement.addUser}</span>
              </h3>
              <button
                onClick={() => setShowAddUserModal(false)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.userManagement.userName}
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder={translateRawUi('e.g. Hassan Mohamed')}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500/50"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.userManagement.userEmail}
                </label>
                <input
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder={translateRawUi('name@example.com')}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500/50"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.userManagement.assignedRole}
                </label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as UserRole)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  {assignableRoles.map(r => (
                    <option key={r} value={r}>{t.roles[r as keyof typeof t.roles] || r}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.userManagement.branchOffice}
                </label>
                <select
                  value={newBranch}
                  onChange={(e) => setNewBranch(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500/50"
                  required
                >
                  <option value="">{translateRawUi('Select Branch')}</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.code})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddUserModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  {t.actions.cancel}
                </button>
                <button
                  type="submit"
                  disabled={creatingUser || (!isOwnerUser && !isHqUser)}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold flex items-center gap-2 cursor-pointer"
                >
                  {creatingUser ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : t.actions.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-emerald-400" />
                <span>{t.userManagement.editUser}</span>
              </h3>
              <button
                onClick={() => setSelectedUser(null)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleUpdateUser} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {translateRawUi('User Account')}
                </label>
                <input
                  type="text"
                  value={`${selectedUser.displayName} (${selectedUser.email})`}
                  disabled
                  className="w-full bg-slate-950/60 border border-slate-800/80 rounded-xl px-3 py-2 text-xs text-slate-400 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.userManagement.assignedRole}
                </label>
                <select
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value as UserRole)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  {assignableRoles.map(r => (
                    <option key={r} value={r}>{t.roles[r as keyof typeof t.roles] || r}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.userManagement.accountStatus}
                </label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as 'active' | 'suspended' | 'pending')}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  <option value="active">{translateRawUi('Active')}</option>
                  <option value="suspended">{translateRawUi('Suspended')}</option>
                  <option value="pending">{t.legacyUi.pendingLabel}</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedUser(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  {t.actions.cancel}
                </button>
                <button
                  type="submit"
                  disabled={updatingUser}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold flex items-center gap-2 cursor-pointer"
                >
                  {updatingUser ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : t.actions.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
